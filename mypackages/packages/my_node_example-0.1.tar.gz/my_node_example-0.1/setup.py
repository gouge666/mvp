from setuptools import setup

setup(
    name='my_node_example',
    packages=['my_node_example'],
    description='Hello world enterprise edition',
    version='0.1',
    url='http://github.com/example/my_node_example',
    author='Linode',
    author_email='docs@linode.com',
    keywords=['pip','linode','example']
)